/*------------------------------------------------------------------------------
 * Oracle Certified Professional Java SE 7 Programmer Exams 1Z0-804 and 1Z0-805: 
 * A Comprehensive OCPJP 7 Certification Guide
 * by SG Ganesh and Tushar Sharma
------------------------------------------------------------------------------*/
public class RDBMSDAO implements CircleDAO {
	@Override
	public void insertCircle(CircleTransfer circle) {
		// insertCircle implementation
		System.out.println("insertCircle implementation");
	}
	@Override
	public CircleTransfer findCircle(int id) {
		// findCircle implementation
		return null;
	}
	@Override
	public void deleteCircle(int id) {
		// deleteCircle implementation
	}
}
