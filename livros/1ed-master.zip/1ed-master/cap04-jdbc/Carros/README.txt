Importe o dump do MySQL para testar:

1) Fazer download

https://raw.githubusercontent.com/livrowebservices/capitulos/master/backup_carros.sql

2) Comando para importar o dump.

mysql -u livro -plivro123 livro < backup_carros.sql