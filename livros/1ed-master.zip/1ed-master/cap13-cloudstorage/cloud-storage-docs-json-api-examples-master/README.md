cloud-storage-docs-json-api-examples
====================================

Examples used in Google Cloud Storage documentation. For more information see:

- https://developers.google.com/storage/docs/json_api/v1/json-api-java-samples
- https://developers.google.com/storage/docs/json_api/v1/json-api-python-samples

Related client library examples (in that they also use the JSON API):

- https://github.com/GoogleCloudPlatform/storage-getting-started-javascript
- https://github.com/GoogleCloudPlatform/storage-getting-started-go
- https://github.com/GoogleCloudPlatform/storage-getting-started-php
