
public class Constants {

	public static final String BUCKET_NAME = "livrolecheta2";
	/**
	 * // Arquivo p12 baixado no console no momento de criar a chave.
	 */
	public static final String P12_FILE = "Teste-4fd6519f07fc.p12";
	/**
	 * // Campo Email address criado no console.
	 */
	public static final String ACCOUNT_ID = "483156701327-compute@developer.gserviceaccount.com";
	
}
